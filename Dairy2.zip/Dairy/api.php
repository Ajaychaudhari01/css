<?php 

/* Template Name: Api*/
 ?>

<?php 
echo "hello Chacha !";
$ch = curl_init();
// Disable SSL verification
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
// Will return the response, if false it print the response
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Set the url
curl_setopt($ch, CURLOPT_URL,'http://enginetest.megafun.no/bookings/getbookingtypes/
');
// Execute
$result=curl_exec($ch);

// Will dump a beauty json <3
$fr=json_decode($result, true);
print_r($fr);
?>