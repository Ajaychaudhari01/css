# This documentation and the objects it documents have been deprecated

For the README for this repository, see README.md in the root level of the repository. For examples of how to interact with the current Authorize.Net API, see our new sample code GitHub repository at https://github.com/AuthorizeNet/sample-code-php.
