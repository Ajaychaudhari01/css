<?php

session_start();


?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- Font Awesome -->
	<link
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
	rel="stylesheet"
	/>
	<!-- Google Fonts -->
	<link
	href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
	rel="stylesheet"
	/>
	<!-- MDB -->
	<link
	href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.0.0/mdb.min.css"
	rel="stylesheet"
	/>
</head>
<body>

	<!-- Navbar-->
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<div class="container-fluid justify-content-between">
			<!-- Left elements -->
			<div class="d-flex">
				<!-- Brand -->
				<a class="navbar-brand me-2 mb-1 d-flex align-items-center" href="#">
					<img
					src="https://mdbcdn.b-cdn.net/img/logo/mdb-transaprent-noshadows.webp"
					height="20"
					alt="MDB Logo"
					loading="lazy"
					style="margin-top: 2px;"
					/>
				</a>

				<!-- Search form -->
				<form class="input-group w-auto my-auto d-none d-sm-flex">
					<input
					autocomplete="off"
					type="search"
					class="form-control rounded"
					placeholder="Search"
					style="min-width: 125px;"
					/>
					<span class="input-group-text border-0 d-none d-lg-flex"
					><i class="fas fa-search"></i
						></span>
					</form>
				</div>
				<!-- Left elements -->

				<!-- Center elements -->
				<ul class="navbar-nav flex-row d-none d-md-flex">
					<li class="nav-item me-3 me-lg-1 active">
						<a class="nav-link" href="#">
							<span><i class="fas fa-home fa-lg"></i></span>
							<span class="badge rounded-pill badge-notification bg-danger">1</span>
						</a>
					</li>


					<li class="nav-item me-3 me-lg-1">
						<a class="nav-link" href="#">
							<span><i class="fas fa-users fa-lg"></i></span>
							<span class="badge rounded-pill badge-notification bg-danger">2</span>
						</a>
					</li>
				</ul>
				<!-- Center elements -->

				<!-- Right elements -->
				<ul class="navbar-nav flex-row">
					<li class="nav-item me-3 me-lg-1">
						<a class="nav-link d-sm-flex align-items-sm-center" href="#">
							<img
							src="https://mdbcdn.b-cdn.net/img/new/avatars/1.webp"
							class="rounded-circle"
							height="22"
							alt="Black and White Portrait of a Man"
							loading="lazy"
							/>
							<strong class="d-none d-sm-block ms-1">John</strong>
						</a>
					</li>
					<li class="nav-item me-3 me-lg-1">
						<a class="nav-link" href="#">
							<span><i class="fas fa-plus-circle fa-lg"></i></span>
						</a>
					</li>
					<li class="nav-item dropdown me-3 me-lg-1">
						<a
						class="nav-link dropdown-toggle hidden-arrow"
						href="#"
						id="navbarDropdownMenuLink"
						role="button"
						data-mdb-toggle="dropdown"
						aria-expanded="false"
						>
						<i class="fas fa-comments fa-lg"></i>

						<span class="badge rounded-pill badge-notification bg-danger">6</span>
					</a>
					<ul
					class="dropdown-menu dropdown-menu-end"
					aria-labelledby="navbarDropdownMenuLink"
					>
					<li>
						<a class="dropdown-item" href="#">Some news</a>
					</li>
					<li>
						<a class="dropdown-item" href="#">Another news</a>
					</li>
					<li>
						<a class="dropdown-item" href="#">Something else here</a>
					</li>
				</ul>
			</li>
		</ul>
		<!-- Right elements -->
	</div>
</nav>
<!-- Navbar -->




<section class="mt-5">
	<div class="container m-3">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				
				<!-- Pills navs -->
				<ul class="nav nav-pills nav-justified mb-3" id="ex1" role="tablist">
					<li class="nav-item" role="presentation">
						<a
						class="nav-link active"
						id="tab-login"
						data-mdb-toggle="pill"
						href="#pills-login"
						role="tab"
						aria-controls="pills-login"
						aria-selected="true"
						>Login</a
						>
					</li>
					<li class="nav-item" role="presentation">
						<a
						class="nav-link"
						id="tab-register"
						data-mdb-toggle="pill"
						href="#pills-register"
						role="tab"
						aria-controls="pills-register"
						aria-selected="false"
						>Register</a
						>
					</li>
				</ul>
				<!-- Pills navs -->

				<!-- Pills content -->
				<div class="tab-content">
					<div class="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
						<form method="post">
							<!-- Email input -->
							<div class="form-outline mb-4">
								<input type="text" name="loginName" class="form-control" />
								<label class="form-label" for="loginName">Email or username</label>
							</div>

							<!-- Password input -->
							<div class="form-outline mb-4">
								<input type="password" name="loginPassword" class="form-control" />
								<label class="form-label" for="loginPassword">Password</label>
							</div>
							<!-- Submit button -->
							<button type="submit"  name="login" class="btn btn-primary btn-block mb-4">Sign in</button>

						</form>
					</div>




					<div class="tab-pane fade" id="pills-register" role="tabpanel" aria-labelledby="tab-register">
						<form method="post">
							<!-- Username input -->
							<div class="form-outline mb-1">
								<input type="text" name="username" class="form-control" />
								<label class="form-label" for="registerUsername">Username</label>
							</div>
							<!-- Name input -->
							<div class="form-outline mb-1">
								<input type="text" name="fname" class="form-control" />
								<label class="form-label" for="registerName">FirstName</label>
							</div>
							<!-- Name input -->
							<div class="form-outline mb-1">
								<input type="text" name="lname" class="form-control" />
								<label class="form-label" for="registerName">LastName</label>
							</div>

							<!-- Email input -->
							<div class="form-outline mb-1">
								<input type="email" name="email" class="form-control" />
								<label class="form-label" for="registerEmail">Email</label>
							</div>

							<!-- Password input -->
							<div class="form-outline mb-1">
								<input type="password" name="password" class="form-control" />
								<label class="form-label" for="registerPassword">Password</label>
							</div>

							<!-- Repeat Password input -->
							<div class="form-outline mb-1">
								<input type="password" name="registerRepeatPassword" class="form-control" />
								<label class="form-label" for="registerRepeatPassword">Repeat password</label>
							</div>

							<!-- Dateinput -->
							<div class="form-outline mb-1">
								<input type="date" name="dob" class="form-control" />
								<label class="form-label" for="registerRepeatPassword">DOB</label>
							</div>

							<!-- Phone input -->
							<div class="form-outline mb-1">
								<input type="number" name="phone" class="form-control" />
								<label class="form-label" for="registerRepeatPassword">Phone</label>
							</div>

							<!-- Submit button -->
							<button type="btn" name="register" class="btn btn-primary btn-block mb-3">Sign in</button>
						</form>
					</div>
				</div>
				<!-- Pills content -->
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>

</section>

href="admin.php?page=Update&action=Update&id=<?php echo $List->id ;?>

<!-- MDB -->
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.0.0/mdb.min.js"
></script>
</body>
</html>


<?php
if(isset($_POST['register'])){

  global $wpdb;
  global $table_prefix;
  $table = $table_prefix.'people';
	$username = $_POST['username'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$dob = $_POST['dob'];
	$phone = $_POST['phone'];
	$sql= $wpdb->prepare("insert into $table (username,fname,lname,email,password,dob,mobile)
	 values('$username','$fname','$lname','$email','$password','$dob','$phone')");
	$result = $wpdb->query($sql);
	if($result){
		echo "thanks brohter";
	}else{
		echo "kya dekh rha hai re cc";
	}

}


if(isset($_POST['login'])){

  global $wpdb;
  global $table_prefix;
  $table = $table_prefix.'people';
	$username = $_POST['loginName'];
	$password = $_POST['loginPassword'];

	$sql= $wpdb->prepare("select * from $table where username='$username' && password='$password'");
	$result = $wpdb->query($sql);
	if($result){
		$_SESSION['username'] = $username;
		$_SESSION['password'] = $password;
		
				$url = admin_url('admin.php?page=dash');
		echo "<script>window.location.href='$url';</script>";
	}else{
		echo "bhkk bsdk";
	}

}


?>